import os
import psutil




CpuPerc = ObjInf.cpu_percent()

print ('\nCpu Percentage:', CpuPerc)